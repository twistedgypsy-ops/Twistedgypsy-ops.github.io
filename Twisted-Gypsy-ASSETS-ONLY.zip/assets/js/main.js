
(function(){
  const canvas=document.createElement('canvas');canvas.className='sparkles';document.body.appendChild(canvas);
  const ctx=canvas.getContext('2d');let w,h,dpr;const stars=[];const COUNT=90;const GOLD='rgba(212,175,55,';const BG_ALPHA=0.08;
  function resize(){dpr=window.devicePixelRatio||1;w=canvas.width=innerWidth*dpr;h=canvas.height=innerHeight*dpr;canvas.style.width=innerWidth+'px';canvas.style.height=innerHeight+'px'}
  function init(){stars.length=0;for(let i=0;i<COUNT;i++){stars.push({x:Math.random()*w,y:Math.random()*h,r:(Math.random()*1.5+.3)*dpr,a:Math.random()*0.35+0.05,t:Math.random()*Math.PI*2,v:Math.random()*0.0008+0.00025})}}
  function tick(){ctx.fillStyle='rgba(11,11,14,'+BG_ALPHA+')';ctx.fillRect(0,0,w,h);for(const s of stars){s.t+=s.v;const pulse=(Math.sin(s.t)+1)/2;const alpha=s.a*(0.35+0.65*pulse);ctx.beginPath();ctx.arc(s.x,s.y,s.r*(0.6+0.4*pulse),0,Math.PI*2);ctx.fillStyle=GOLD+alpha+')';ctx.fill();s.x+=Math.cos(s.t)*0.05;s.y+=Math.sin(s.t)*0.03;if(s.x<-10)s.x=w+10;if(s.y<-10)s.y=h+10;if(s.x>w+10)s.x=-10;if(s.y>h+10)s.y=-10}requestAnimationFrame(tick)}
  window.addEventListener('resize',()=>{resize();init()});resize();init();tick();
})();
